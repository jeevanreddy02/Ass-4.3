const express = require('express');
const mongoose = require('mongoose');
const url = 'mongodb://localhost/MovieDB';

const app = express();

mongoose.connect(url, { useNewUrlParser: true });
const con = mongoose.connection;

con.on('open', () => {
    console.log('connected...');
});

app.use(express.json());

const movieRouter = require('./routes/movies');
app.use('/movies', movieRouter); // Corrected syntax

// Define a route for the root path
app.get('/', (req, res) => {
    res.send('Welcome to the Movie Collection Details!');
});

app.listen(5000, () => {
    console.log('Server started');
});
