const mongoose= require("mongoose")
var Schema= mongoose.Schema;

var movieSchema = new Schema({
    movie_name: {
        type: String,
        required: true
    },
    year: {
        type: Number,
        required: true
    },
    genre: {
        type: String,
        required: true
    },
    director: {
        type: String,
        required: true
    },
    cast: {
        type: String,
        required: true
    },
    rating: {
        type: Number,
        required: true
    },
});

module.exports = mongoose.model('movie', movieSchema);